                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2824113
i3Mega Camera Mount v2 +star trek edition by Lizard_Wizard is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

My second attempt at a camera mount for the i3 Mega 3d printer.  
I didn't realise the anycubic mega has versions with different thickness metal sheet under the base. 
Its what I use for the camera mount.
This version has two varying thicknesses...Should be good to go.
I printed with just skirt. Worked ok for me.

Tempted to shape the top oval...make it look like a star trek ship :-D
**DONE**
shhhhhhhh, Dont tell the Trekkies!!


https://youtu.be/qSaZ1YLjbDI

Camera mount in action:
https://youtu.be/LifpdWB6-f4

Update:
Fixed the camera mount hole issue.


# Print Settings

Printer: Anycubic i3 MEGA
Rafts: No
Supports: No
Resolution: .2
Infill: 20

Notes: 
1 suggestion for good bed adhesion; maybe try not have the cooling fan come on until 1 or 2 mm.
You can set this in Cura by going to the Cooling section.  Select the Cog to get into settings. Select "Regular fan speed at height".  I put mine to 1mm

When finished & cooled down.....the ship will crash land to let you know its done!